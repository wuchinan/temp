Please NOTE:
The finished file 01 - Introduction - Finished.xlsm contains the reference code for sections 01 through 03. Enjoy!