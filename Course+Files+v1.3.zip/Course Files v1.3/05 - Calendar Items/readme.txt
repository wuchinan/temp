Please NOTE:
The finished file 05 - Calendar Items - Finished.xlsm contains the reference code for sections 05 and 06. Enjoy!