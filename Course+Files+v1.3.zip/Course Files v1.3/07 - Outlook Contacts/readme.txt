Please NOTE:
The finished file 07 - Outlook Contacts - CLEAN.xlsm contains the reference code for sections 07 and 08. Enjoy!