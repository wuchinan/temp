Please NOTE:
The finished file in section 01 called "01 - Introduction - Finished.xlsm" contains the reference code for sections 01 through 03. Enjoy!